# Basket Ball Dunk


## Installation

In the project directory, you can run:

```bash
# installs required packages
npm install 

# Runs the app in the development mode.
npm start
```

## Steps to run project

```
npm start
```

## Steps to build project

```
npm run build
```