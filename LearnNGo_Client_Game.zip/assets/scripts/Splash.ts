
import { _decorator, Component, Node, LabelComponent, ProgressBarComponent, director } from 'cc';
const { ccclass, property } = _decorator;

/**
 * Predefined variables
 * Name = Loading
 * DateTime = Sun Apr 10 2022 15:10:22 GMT+0700 (Indochina Time)
 * Author = thanhthien2014
 * FileBasename = Loading.ts
 * FileBasenameNoExtension = Loading
 * URL = db://assets/scripts/Loading.ts
 * ManualUrl = https://docs.cocos.com/creator/3.4/manual/en/
 *
 */
 
@ccclass('Loading')
export class Loading extends Component {
    // [1]
    percent = 0;

    // [2]
    @property(ProgressBarComponent)
    progressBar:ProgressBarComponent
    @property (LabelComponent)
    lbPercent: LabelComponent


    start () {
        // [3]
        this.progressBar.progress = 0;
        this.lbPercent.string = "0%"

    }

    update (deltaTime: number) {
        // [4]
        this.percent++;
        if(this.percent>=100){
            this.percent = 100;
            director.loadScene("home")
        }
        this.progressBar.progress = this.percent/100;
        this.lbPercent.string = `${this.percent}%`;
        
    }
}

/**
 * [1] Class member could be defined like this.
 * [2] Use `property` decorator if your want the member to be serializable.
 * [3] Your initialization goes here.
 * [4] Your update function goes here.
 *
 * Learn more about scripting: https://docs.cocos.com/creator/3.4/manual/en/scripting/
 * Learn more about CCClass: https://docs.cocos.com/creator/3.4/manual/en/scripting/ccclass.html
 * Learn more about life-cycle callbacks: https://docs.cocos.com/creator/3.4/manual/en/scripting/life-cycle-callbacks.html
 */
