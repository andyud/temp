
import { _decorator, Component, Node, AudioSource, EventTouch, Prefab, instantiate, director } from 'cc';
import { audioManager } from './audioManager';
const { ccclass, property } = _decorator;

/**
 * Predefined variables
 * Name = Home
 * DateTime = Sun Apr 10 2022 16:46:03 GMT+0700 (Indochina Time)
 * Author = thanhthien2014
 * FileBasename = Home.ts
 * FileBasenameNoExtension = Home
 * URL = db://assets/scripts/Home.ts
 * ManualUrl = https://docs.cocos.com/creator/3.4/manual/en/
 *
 */
 
@ccclass('Home')
export class Home extends Component {
    // [1]
    // dummy = '';

    // [2]
    // @property
    // serializableDummy = 0;
    @property(AudioSource) 
    _audioSource: AudioSource = null!
    @property(Prefab)
    pfSettings:Prefab = null
    settingsHandle:Node = null
    start () {
        // [3]
        const audioSource = this.node.getComponent(AudioSource)! ;
        this._audioSource = audioSource;
        audioManager.instance.init(this._audioSource);
        audioManager.instance.playMusic(true);
    }
    onClick(event: EventTouch, customEventData: string){
        switch(customEventData){
            case "onSettings":
                this.settingsHandle = instantiate(this.pfSettings)
                this.node.addChild(this.settingsHandle)
                break
            case "onMultiChoiceMath":
                director.loadScene("multichoicemath")
                break
            case "onColorBook":
                break

        }
        // this._audioSource.play();
        // audioManager.instance.playSound()
    }
    // update (deltaTime: number) {
    //     // [4]
    // }
}

/**
 * [1] Class member could be defined like this.
 * [2] Use `property` decorator if your want the member to be serializable.
 * [3] Your initialization goes here.
 * [4] Your update function goes here.
 *
 * Learn more about scripting: https://docs.cocos.com/creator/3.4/manual/en/scripting/
 * Learn more about CCClass: https://docs.cocos.com/creator/3.4/manual/en/scripting/ccclass.html
 * Learn more about life-cycle callbacks: https://docs.cocos.com/creator/3.4/manual/en/scripting/life-cycle-callbacks.html
 */
