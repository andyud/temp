/// <reference path="/Applications/CocosCreator/Creator/3.4.0/CocosCreator.app/Contents/Resources/resources/3d/engine/@types/jsb.d.ts"/>
