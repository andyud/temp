System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2", "__unresolved_3", "__unresolved_4"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Button, Component, Node, Prefab, SelectPlayer, Player, GameMgr, SelectColor, _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _crd, ccclass, property, LUDO_STATE, Ludo;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfSelectPlayer(extras) {
    _reporterNs.report("SelectPlayer", "./SelectPlayer", _context.meta, extras);
  }

  function _reportPossibleCrUseOfPlayer(extras) {
    _reporterNs.report("Player", "./Player", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGameMgr(extras) {
    _reporterNs.report("GameMgr", "./GameMgr", _context.meta, extras);
  }

  function _reportPossibleCrUseOfSelectColor(extras) {
    _reporterNs.report("SelectColor", "./SelectColor", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Button = _cc.Button;
      Component = _cc.Component;
      Node = _cc.Node;
      Prefab = _cc.Prefab;
    }, function (_unresolved_2) {
      SelectPlayer = _unresolved_2.SelectPlayer;
    }, function (_unresolved_3) {
      Player = _unresolved_3.Player;
    }, function (_unresolved_4) {
      GameMgr = _unresolved_4.GameMgr;
    }, function (_unresolved_5) {
      SelectColor = _unresolved_5.SelectColor;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "8245cHBdiBK4JE6zm1AbDHL", "Ludo", undefined);

      __checkObsolete__(['_decorator', 'Button', 'Component', 'Node', 'Prefab']);

      ({
        ccclass,
        property
      } = _decorator);
      LUDO_STATE = {
        NONE: 0,
        SELECT_PLAYER: 1,
        SELECT_COLOR: 2,
        START: 3,
        INGAME: 4,
        END_GAME: 5
      };

      _export("Ludo", Ludo = (_dec = ccclass('Ludo'), _dec2 = property({
        type: Button
      }), _dec3 = property({
        type: Node
      }), _dec4 = property({
        type: Node
      }), _dec5 = property([Node]), _dec6 = property({
        type: Prefab
      }), _dec7 = property({
        type: Node
      }), _dec8 = property({
        type: Node
      }), _dec(_class = (_class2 = class Ludo extends Component {
        constructor(...args) {
          super(...args);
          this.gameState = LUDO_STATE.SELECT_PLAYER;
          this.isSoundOn = true;

          //--settings
          _initializerDefineProperty(this, "btnSound", _descriptor, this);

          _initializerDefineProperty(this, "popupSelectPlayers", _descriptor2, this);

          _initializerDefineProperty(this, "popupSelectColor", _descriptor3, this);

          _initializerDefineProperty(this, "greenPaths", _descriptor4, this);

          _initializerDefineProperty(this, "pfPlayerAnim", _descriptor5, this);

          _initializerDefineProperty(this, "board", _descriptor6, this);

          _initializerDefineProperty(this, "playerNode", _descriptor7, this);

          this.players = [];
        }

        start() {
          this.popupSelectPlayers.getComponent(_crd && SelectPlayer === void 0 ? (_reportPossibleCrUseOfSelectPlayer({
            error: Error()
          }), SelectPlayer) : SelectPlayer).init(() => {
            //--next
            this.gameState = LUDO_STATE.SELECT_COLOR;
            this.updateGameState();
          });
          this.popupSelectColor.getComponent(_crd && SelectColor === void 0 ? (_reportPossibleCrUseOfSelectColor({
            error: Error()
          }), SelectColor) : SelectColor).init(() => {
            //--next
            this.gameState = LUDO_STATE.START;
            this.updateGameState();
          });
          this.updateGameState();
        }

        initGamePlay() {
          for (let i = 0; i < (_crd && GameMgr === void 0 ? (_reportPossibleCrUseOfGameMgr({
            error: Error()
          }), GameMgr) : GameMgr).instance.players.length; i++) {
            let playerInfo = (_crd && GameMgr === void 0 ? (_reportPossibleCrUseOfGameMgr({
              error: Error()
            }), GameMgr) : GameMgr).instance.players[i];

            if (playerInfo.isActive) {
              this.playerNode.children[i].active = true;
              this.players.push(this.playerNode.children[i]);
              this.playerNode.children[i].getComponent(_crd && Player === void 0 ? (_reportPossibleCrUseOfPlayer({
                error: Error()
              }), Player) : Player).init(playerInfo);
            } else {
              this.playerNode.children[i].active = false;
            }
          }
        }

        update(deltaTime) {}

        updateGameState() {
          this.popupSelectPlayers.active = false;
          this.popupSelectColor.active = false;
          this.board.active = false;
          this.playerNode.active = false;

          switch (this.gameState) {
            case LUDO_STATE.SELECT_PLAYER:
              this.popupSelectPlayers.active = true;
              break;

            case LUDO_STATE.SELECT_COLOR:
              this.popupSelectColor.active = true;
              break;

            case LUDO_STATE.START:
              this.board.active = true;
              this.playerNode.active = true;
              this.initGamePlay();
              break;
          }
        }

        onSound() {
          this.isSoundOn = !this.isSoundOn;

          if (this.isSoundOn) {
            this.btnSound.node.children[0].active = true;
            this.btnSound.node.children[1].active = false;
          } else {
            this.btnSound.node.children[0].active = false;
            this.btnSound.node.children[1].active = true;
          }
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "btnSound", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "popupSelectPlayers", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "popupSelectColor", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "greenPaths", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return [];
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "pfPlayerAnim", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "board", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "playerNode", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=0a5ab2601fac89a144aebd7d3362d12a0c48cf4b.js.map