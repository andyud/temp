System.register([], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: async function () {
      // Auto generated represents the prerequisite imports of project modules.
      await (async () => {
        const requests = [() => _context.import("__unresolved_0"), () => _context.import("__unresolved_1"), () => _context.import("__unresolved_2"), () => _context.import("__unresolved_3"), () => _context.import("__unresolved_4"), () => _context.import("__unresolved_5"), () => _context.import("__unresolved_6")];

        for (const request of requests) {
          try {
            await request();
          } catch (_err) {// The error should have been caught by executor.
          }
        }
      })();
    }
  };
});
//# sourceMappingURL=09e496b395f3362281c93269a29d6d47678870a4.js.map