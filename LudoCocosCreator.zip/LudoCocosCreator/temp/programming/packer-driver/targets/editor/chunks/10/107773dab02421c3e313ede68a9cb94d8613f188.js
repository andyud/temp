System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, Label, Node, GameMgr, PlayerAnim, _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _crd, ccclass, property, Player;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfGameMgr(extras) {
    _reporterNs.report("GameMgr", "./GameMgr", _context.meta, extras);
  }

  function _reportPossibleCrUseOfPlayerAnim(extras) {
    _reporterNs.report("PlayerAnim", "./PfPlayerAnim", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Label = _cc.Label;
      Node = _cc.Node;
    }, function (_unresolved_2) {
      GameMgr = _unresolved_2.GameMgr;
    }, function (_unresolved_3) {
      PlayerAnim = _unresolved_3.PlayerAnim;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "13a01XSZF5NC4oVwEZDt0D0", "Player", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Game', 'Label', 'Node']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("Player", Player = (_dec = ccclass('Player'), _dec2 = property({
        type: Label
      }), _dec3 = property({
        type: Node
      }), _dec4 = property({
        type: Node
      }), _dec5 = property({
        type: Node
      }), _dec6 = property([Node]), _dec7 = property({
        type: Node
      }), _dec8 = property({
        type: Node
      }), _dec(_class = (_class2 = class Player extends Component {
        constructor(...args) {
          super(...args);
          this.info = {
            name: "",
            color: (_crd && GameMgr === void 0 ? (_reportPossibleCrUseOfGameMgr({
              error: Error()
            }), GameMgr) : GameMgr).instance.PLAYER_COLOR.RED,
            isMain: false,
            isActive: false
          };

          _initializerDefineProperty(this, "lbName", _descriptor, this);

          _initializerDefineProperty(this, "colors", _descriptor2, this);

          _initializerDefineProperty(this, "dices", _descriptor3, this);

          _initializerDefineProperty(this, "diceAnim", _descriptor4, this);

          _initializerDefineProperty(this, "path", _descriptor5, this);

          _initializerDefineProperty(this, "turnArrow", _descriptor6, this);

          _initializerDefineProperty(this, "turnBg", _descriptor7, this);

          //white 11 -> green4 -> white 12
          //white 23 -> blue4 -> white 24
          //white 35 -> yellow4 -> white 36
          //white 47 -> red4 -> white 0
          //red 0, green: 12
          this.horses = [];
        }

        init(info) {
          for (let i = 0; i < this.colors.children.length; i++) {
            this.colors.children[i].active = false;
          }

          for (let j = 0; j < this.dices.children.length; j++) {
            this.dices.children[j].active = false;
          }

          this.lbName.node.active = false;
          this.turnArrow.active = false;
          this.info = info;
          this.lbName.string = info.name;
          this.lbName.node.active = true;
          this.colors.children[this.info.color].active = true;
        }

        pushHorse(horse) {
          this.horses.push(horse);
          horse.position = this.path[this.horses.length - 1].position;
          horse.getComponent(_crd && PlayerAnim === void 0 ? (_reportPossibleCrUseOfPlayerAnim({
            error: Error()
          }), PlayerAnim) : PlayerAnim).setFocus(true);
          horse.getComponent(_crd && PlayerAnim === void 0 ? (_reportPossibleCrUseOfPlayerAnim({
            error: Error()
          }), PlayerAnim) : PlayerAnim).init(this.info.color);
        }

        setTurn(isTurn) {
          if (isTurn) {
            this.turnArrow.active = true; // this.turnBg.active = true;
          } else {
            this.turnArrow.active = false; // this.turnBg.active = false;
          }
        }

        start() {}

        update(deltaTime) {}

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "lbName", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "colors", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "dices", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "diceAnim", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "path", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return [];
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "turnArrow", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "turnBg", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=107773dab02421c3e313ede68a9cb94d8613f188.js.map