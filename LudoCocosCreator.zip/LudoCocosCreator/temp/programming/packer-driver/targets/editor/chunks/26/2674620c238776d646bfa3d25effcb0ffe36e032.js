System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2", "__unresolved_3", "__unresolved_4"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Button, Component, instantiate, Node, Prefab, SelectPlayer, Player, GameMgr, SelectColor, _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _crd, ccclass, property, LUDO_STATE, Ludo;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfSelectPlayer(extras) {
    _reporterNs.report("SelectPlayer", "./SelectPlayer", _context.meta, extras);
  }

  function _reportPossibleCrUseOfPlayer(extras) {
    _reporterNs.report("Player", "./Player", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGameMgr(extras) {
    _reporterNs.report("GameMgr", "./GameMgr", _context.meta, extras);
  }

  function _reportPossibleCrUseOfSelectColor(extras) {
    _reporterNs.report("SelectColor", "./SelectColor", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Button = _cc.Button;
      Component = _cc.Component;
      instantiate = _cc.instantiate;
      Node = _cc.Node;
      Prefab = _cc.Prefab;
    }, function (_unresolved_2) {
      SelectPlayer = _unresolved_2.SelectPlayer;
    }, function (_unresolved_3) {
      Player = _unresolved_3.Player;
    }, function (_unresolved_4) {
      GameMgr = _unresolved_4.GameMgr;
    }, function (_unresolved_5) {
      SelectColor = _unresolved_5.SelectColor;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "8245cHBdiBK4JE6zm1AbDHL", "Ludo", undefined);

      __checkObsolete__(['_decorator', 'Button', 'Component', 'instantiate', 'Node', 'Prefab']);

      ({
        ccclass,
        property
      } = _decorator);
      LUDO_STATE = {
        NONE: 0,
        SELECT_PLAYER: 1,
        SELECT_COLOR: 2,
        START: 3,
        INIT_TURN: 4,
        START_TURN: 5,
        END_TURN: 6,
        END_GAME: 7
      };

      _export("Ludo", Ludo = (_dec = ccclass('Ludo'), _dec2 = property({
        type: Button
      }), _dec3 = property({
        type: Node
      }), _dec4 = property({
        type: Node
      }), _dec5 = property([Node]), _dec6 = property({
        type: Prefab
      }), _dec7 = property({
        type: Node
      }), _dec8 = property({
        type: Node
      }), _dec(_class = (_class2 = class Ludo extends Component {
        constructor(...args) {
          super(...args);
          this.gameState = LUDO_STATE.SELECT_PLAYER;
          this.isSoundOn = true;

          //--settings
          _initializerDefineProperty(this, "btnSound", _descriptor, this);

          _initializerDefineProperty(this, "popupSelectPlayers", _descriptor2, this);

          _initializerDefineProperty(this, "popupSelectColor", _descriptor3, this);

          _initializerDefineProperty(this, "greenPaths", _descriptor4, this);

          _initializerDefineProperty(this, "pfPlayerAnim", _descriptor5, this);

          _initializerDefineProperty(this, "board", _descriptor6, this);

          _initializerDefineProperty(this, "players", _descriptor7, this);

          this.turnIdx = -1;
          this.iEndGame = -1;
        }

        //id of player win if have
        start() {
          this.popupSelectPlayers.getComponent(_crd && SelectPlayer === void 0 ? (_reportPossibleCrUseOfSelectPlayer({
            error: Error()
          }), SelectPlayer) : SelectPlayer).init(() => {
            //--next
            this.gameState = LUDO_STATE.SELECT_COLOR;
            this.updateGameState();
          });
          this.popupSelectColor.getComponent(_crd && SelectColor === void 0 ? (_reportPossibleCrUseOfSelectColor({
            error: Error()
          }), SelectColor) : SelectColor).init(() => {
            //--next
            this.gameState = LUDO_STATE.START;
            this.updateGameState();
          });
          this.updateGameState();
        }

        initGamePlay() {
          //--init players
          for (let i = 0; i < (_crd && GameMgr === void 0 ? (_reportPossibleCrUseOfGameMgr({
            error: Error()
          }), GameMgr) : GameMgr).instance.players.length; i++) {
            let playerInfo = (_crd && GameMgr === void 0 ? (_reportPossibleCrUseOfGameMgr({
              error: Error()
            }), GameMgr) : GameMgr).instance.players[i];

            if (playerInfo.isActive) {
              this.players.children[i].active = true;
              this.players.children[i].getComponent(_crd && Player === void 0 ? (_reportPossibleCrUseOfPlayer({
                error: Error()
              }), Player) : Player).init(playerInfo, action => {
                if (action == 1) {
                  //end scroll
                  this.endScroll();
                } else if (action == 2) {
                  //end move
                  //--next player or continue or end game?
                  //1.check end game
                  if (this.checkEndGame()) {
                    this.showGameResult();
                    return;
                  } //2. check previous result if 1 or 6

                }
              });
            } else {
              this.players.children[i].active = false;
            }
          } //--push horse


          for (let j = 0; j < this.players.children.length; j++) {
            if (this.players.children[j].active === false) continue;

            for (let k = 0; k < 4; k++) {
              let horse = instantiate(this.pfPlayerAnim);
              this.node.addChild(horse);
              this.players.children[j].getComponent(_crd && Player === void 0 ? (_reportPossibleCrUseOfPlayer({
                error: Error()
              }), Player) : Player).pushHorse(horse);
            }
          } //init turn


          this.initTurn();
        } //--gameplay


        initTurn() {
          for (let i = 0; i < this.players.children.length; i++) {
            if (this.players.children[i].getComponent(_crd && Player === void 0 ? (_reportPossibleCrUseOfPlayer({
              error: Error()
            }), Player) : Player).info.isMain) {
              this.turnIdx = i;
              break;
            }
          }

          this.startTurn();
        }

        startTurn() {
          for (let i = 0; i < this.players.children.length; i++) {
            if (this.turnIdx === i) {
              this.players.children[i].getComponent(_crd && Player === void 0 ? (_reportPossibleCrUseOfPlayer({
                error: Error()
              }), Player) : Player).setTurn(true);
            } else {
              this.players.children[i].getComponent(_crd && Player === void 0 ? (_reportPossibleCrUseOfPlayer({
                error: Error()
              }), Player) : Player).setTurn(false);
            }
          }
        }

        onTurn(event, customEventData) {
          let playerId = parseInt(customEventData);
          this.players.children[playerId].getComponent(_crd && Player === void 0 ? (_reportPossibleCrUseOfPlayer({
            error: Error()
          }), Player) : Player).rollDice();
        }

        endScroll() {
          //--roll done - logic game here
          let player = this.players.children[this.turnIdx].getComponent(_crd && Player === void 0 ? (_reportPossibleCrUseOfPlayer({
            error: Error()
          }), Player) : Player);

          if (player.diceRes == 1 || player.diceRes == 6) {
            player.setEnableAllHorse();
          }
        }

        checkEndGame() {
          for (let i = 0; i < this.players.children.length; i++) {
            let player = this.players.children[i];
            this.iEndGame = player.getComponent(_crd && Player === void 0 ? (_reportPossibleCrUseOfPlayer({
              error: Error()
            }), Player) : Player).checkEndGame();

            if (this.iEndGame != -1) {
              return true;
            }
          }

          return false;
        }

        showGameResult() {
          let youWIn = false;

          for (let i = 0; i < this.players.children.length; i++) {
            let player = this.players.children[i].getComponent(_crd && Player === void 0 ? (_reportPossibleCrUseOfPlayer({
              error: Error()
            }), Player) : Player);

            if (player.info.isMain && this.iEndGame === player.info.color) {
              youWIn = true;
              break;
            }
          }

          if (youWIn) {//show you win
          } else {//show you lose
          }
        }

        update(deltaTime) {}

        updateGameState() {
          this.popupSelectPlayers.active = false;
          this.popupSelectColor.active = false;
          this.board.active = false;
          this.players.active = false;

          switch (this.gameState) {
            case LUDO_STATE.SELECT_PLAYER:
              this.popupSelectPlayers.active = true;
              break;

            case LUDO_STATE.SELECT_COLOR:
              this.popupSelectColor.active = true;
              break;

            case LUDO_STATE.START:
              this.board.active = true;
              this.players.active = true;
              this.initGamePlay();
              break;
          }
        }

        onSound() {
          this.isSoundOn = !this.isSoundOn;

          if (this.isSoundOn) {
            this.btnSound.node.children[0].active = true;
            this.btnSound.node.children[1].active = false;
          } else {
            this.btnSound.node.children[0].active = false;
            this.btnSound.node.children[1].active = true;
          }
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "btnSound", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "popupSelectPlayers", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "popupSelectColor", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "greenPaths", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return [];
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "pfPlayerAnim", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "board", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "players", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=2674620c238776d646bfa3d25effcb0ffe36e032.js.map