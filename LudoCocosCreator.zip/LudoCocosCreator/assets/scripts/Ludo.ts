import { _decorator, Button, Component, instantiate, Node, Prefab } from 'cc';
import { SelectPlayer } from './SelectPlayer';
import { Player } from './Player';
import { GameMgr } from './GameMgr';
import { SelectColor } from './SelectColor';
import { GameResult } from './GameResult';
const { ccclass, property } = _decorator;

const LUDO_STATE = {
    NONE: 0,
    SELECT_PLAYER:1,
    SELECT_COLOR:2,
    START : 3,
    INIT_TURN: 4,
    START_TURN:5,
    END_TURN:6,
    END_GAME:7
}

@ccclass('Ludo')
export class Ludo extends Component {
    gameState = LUDO_STATE.SELECT_PLAYER;
    isSoundOn = true;
    //--settings
    @property({type:Button})
    btnSound:Button
    @property({type:Node})
    popupSelectPlayers:Node
    @property({type:Node})
    popupSelectColor:Node
    @property({type:Node})
    popupGameResult:Node
    @property([Node])
    public greenPaths: Node[] = []
    @property({type:Prefab})
    pfPlayerAnim:Prefab
    @property({type:Node})
    board:Node
    @property({type:Node})
    players:Node
    turnIdx = -1;
    iEndGame = -1; //id of player win if have
    start() {
        this.popupSelectPlayers.getComponent(SelectPlayer).init(()=>{
            //--next
            this.gameState = LUDO_STATE.SELECT_COLOR;
            this.updateGameState();
        });
        this.popupSelectColor.getComponent(SelectColor).init(()=>{
            //--next
            this.gameState = LUDO_STATE.START;
            this.updateGameState();
        });
        this.popupGameResult.getComponent(GameResult).init(()=>{
            //
            this.gameState = LUDO_STATE.NONE;
            this.updateGameState();
        });
        this.updateGameState();
    }
    initGamePlay(){
        //--init players
        for(let i=0;i<GameMgr.instance.players.length;i++){
            let playerInfo = GameMgr.instance.players[i];
            if(playerInfo.isActive){
                this.players.children[i].active = true;
                this.players.children[i].getComponent(Player).init(playerInfo,(action:number)=>{
                    if(action==1){//end scroll
                        this.endScroll()
                    } else if(action==2){//end move
                        //--next player or continue or end game?

                        //1.check end game
                        if(this.checkEndGame()){
                            this.showGameResult();
                            return;
                        }

                        //2. check previous result if 1 or 6 or other result
                        this.getNextTurn();
                    }
                });
            } else {
                this.players.children[i].active = false;
            }
        }

        //--push horse
        for(let j=0;j<this.players.children.length;j++){
            if(this.players.children[j].active===false) continue;
            for(let k=0;k<4;k++){
                let horse = instantiate(this.pfPlayerAnim);
                this.node.addChild(horse);
                this.players.children[j].getComponent(Player).pushHorse(horse);
            }
        }

        //init turn
        this.initTurn();
    }

    //--gameplay
    initTurn(){
        for(let i=0;i<this.players.children.length;i++){
            if(this.players.children[i].getComponent(Player).info.isMain){
                this.turnIdx = i;
                break;
            }
        }
        this.startTurn();
    }

    startTurn(){
        for(let i=0;i<this.players.children.length;i++){
            if(this.turnIdx === i){
                this.players.children[i].getComponent(Player).setTurn(true);
            } else {
                this.players.children[i].getComponent(Player).setTurn(false);
            }
        }
    }

    onTurn(event: Event, customEventData: string){
        let playerId = parseInt(customEventData);
        this.players.children[playerId].getComponent(Player).rollDice();
    }

    endScroll(){
        //--roll done - logic game here
        let player = this.players.children[this.turnIdx].getComponent(Player);
        player.setEnableHorse(true);
        if(player.countEnableHorse()==0){
            this.getNextTurn();
        }
    }

    checkEndGame(){
        for(let i=0;i<this.players.children.length;i++){
            let player = this.players.children[i];
            this.iEndGame = player.getComponent(Player).checkEndGame();
            if(this.iEndGame!=-1){
                return true;
            }
        }
        return false;
    }

    showGameResult(){
        let youWIn = false;
        for(let i=0;i<this.players.children.length;i++){
            let player = this.players.children[i].getComponent(Player);
            if(player.info.isMain && this.iEndGame === player.info.color){
                youWIn = true;
                break;
            }
        }
        if(youWIn){
            //show you win
            this.popupGameResult.active = true;
            this.popupGameResult.getComponent(GameResult).setResult(true);
        } else {
            //show you lose
            this.popupGameResult.active = true;
            this.popupGameResult.getComponent(GameResult).setResult(false);
        }
    }
    getNextTurn(){
        for(let i=0;i<this.players.children.length;i++){
            let player = this.players.children[i].getComponent(Player);
            if(player.diceRes == 1 || player.diceRes == 6){
                //--current player will continue to turn
                this.startTurn();
                return;
            }
        }
        //--don't have 1 or 6 -> next player
        while(true){
            this.turnIdx++;
            if(this.turnIdx>=this.players.children.length){
                this.turnIdx = 0;
            }
            if(this.players.children[this.turnIdx].active===true){
                break;
            }
        }
        this.startTurn();
    }
    update(deltaTime: number) {
        
    }

    updateGameState(){
        this.popupSelectPlayers.active = false;
        this.popupSelectColor.active = false;
        this.board.active = false;
        this.players.active = false;
        switch(this.gameState){
            case LUDO_STATE.SELECT_PLAYER:
                this.popupSelectPlayers.active = true;
                break;
            case LUDO_STATE.SELECT_COLOR:
                this.popupSelectColor.active = true;
                break;
            case LUDO_STATE.START:
                this.board.active = true;
                this.players.active = true;
                this.initGamePlay();
                break;
        }
    }
    onSound(){
        this.isSoundOn = !this.isSoundOn;
        if(this.isSoundOn){
            this.btnSound.node.children[0].active = true;
            this.btnSound.node.children[1].active = false;
        } else {
            this.btnSound.node.children[0].active = false;
            this.btnSound.node.children[1].active = true;
        }
    }


}


