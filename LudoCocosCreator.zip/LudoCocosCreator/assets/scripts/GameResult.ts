import { _decorator, Component, Node } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('GameResult')
export class GameResult extends Component {
    @property({type:Node})
    lbWin:Node
    @property({type:Node})
    lbLose:Node
    cb:()=>void
    start() {

    }

    onRestart(){
        this.cb();
        this.node.active = false;
    }
    init(cb:()=>void){
        this.cb = cb;
    }
    setResult(isWin:boolean){
        if(isWin){
            this.lbWin.active = true;
            this.lbLose.active = false;
        } else {
            this.lbWin.active = false;
            this.lbLose.active = true;
        }
    }
}


