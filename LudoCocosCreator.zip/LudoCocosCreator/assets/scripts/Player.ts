import { _decorator, Component, Game, Label, Node, Animation, Button, tween } from 'cc';
import { GameMgr } from './GameMgr';
import { PlayerAnim } from './PfPlayerAnim';
const { ccclass, property } = _decorator;

@ccclass('Player')
export class Player extends Component {
    info = {
        name: "",
        color: GameMgr.instance.PLAYER_COLOR.RED,//color is id of player
        isMain: false,
        isActive: false
    }
    @property({ type: Label })
    lbName: Label
    @property({ type: Node })
    colors: Node
    @property({ type: Node })
    dices: Node
    @property({ type: Node })
    diceAnim: Node
    @property([Node])
    path: Node[] = []
    @property({ type: Node })
    turnArrow: Node
    @property({ type: Node })
    turnBg: Node
    //white 11 -> green4 -> white 12
    //white 23 -> blue4 -> white 24
    //white 35 -> yellow4 -> white 36
    //white 47 -> red4 -> white 0
    //red 0, green: 12
    horses = [];
    diceRes = 0;
    startCell = 0;
    endCell = 0;
    curHorse = null;
    playerAction: (action: number) => void;
    init(info: any, playerAction: (action: number) => void) {
        for (let i = 0; i < this.colors.children.length; i++) {
            this.colors.children[i].active = false;
        }
        for (let j = 0; j < this.dices.children.length; j++) {
            this.dices.children[j].active = false;
        }
        this.lbName.node.active = false;
        this.turnArrow.active = false;

        this.info = info;
        this.lbName.string = info.name;
        this.lbName.node.active = true;
        this.colors.children[this.info.color].active = true;
        this.getComponent(Button).interactable = false;
        this.playerAction = playerAction;
    }

    pushHorse(horse: Node) {
        this.horses.push(horse);
        let horseId = this.horses.length - 1;
        horse.position = this.path[horseId].position;
        horse.getComponent(PlayerAnim).setFocus(false);
        horse.getComponent(PlayerAnim).init(this.info.color, horseId, (horseId: number) => {
            //--disable all horse
            for (let i = 0; i < this.horses.length; i++) {
                let horse = this.horses[i].getComponent(PlayerAnim);
                horse.getComponent(PlayerAnim).setFocus(false);
                if (horseId == i) {//--move horse
                    this.startCell = horse.currentCell;
                    this.endCell = this.startCell + this.diceRes;
                    if (this.startCell < 4) {
                        this.endCell = 4;
                    }
                    else if (this.endCell >= this.path.length) {
                        this.endCell = this.path.length - 1;
                    }
                    //--update current cell
                    horse.currentCell = this.endCell;
                    if (this.endCell == 4) {
                        tween(horse.node)
                            .to(0.2, { position: this.path[this.endCell].position })
                            .call(() => {
                                this.setEnableHorse(false);
                                this.playerAction(2);
                            })
                            .start();
                    } else {
                        this.curHorse = horse;
                        this.moveSmooth();
                    }
                    break;
                }
            }
        });
    }
    moveSmooth() {
        let tempCell = this.startCell;
        this.startCell++;
        if (tempCell <= this.endCell) {
            tween(this.curHorse.node)
                .to(0.06, { position: this.path[tempCell].position },{easing:'backIn'})
                .delay(0.09)
                .call(() => {
                    this.moveSmooth();
                })
                .start();
        }
        else {//end
            this.setEnableHorse(false);
            this.playerAction(2);
        }
    }
    setTurn(isTurn: boolean) {
        if (isTurn) {
            this.getComponent(Button).interactable = true;
            this.turnArrow.active = true;
            this.turnBg.getComponent(Animation).play("bgTurn");
        }
        else {
            this.getComponent(Button).interactable = false;
            this.turnArrow.active = false;
            this.turnBg.getComponent(Animation).stop();
        }
    }

    rollDice() {
        this.getComponent(Button).interactable = false;
        this.diceAnim.active = true;
        this.diceAnim.getComponent(Animation).play('dice');
        let timeout = setTimeout(() => {
            clearTimeout(timeout);
            this.diceAnim.active = false;
            this.setResult();
        }, 200);
    }

    setResult() {
        this.diceRes = GameMgr.instance.randomInt(1, 6);
        for (let i = 0; i < this.dices.children.length; i++) {
            if (i == this.diceRes - 1) {
                this.dices.children[i].active = true;
            } else {
                this.dices.children[i].active = false;
            }
        }
        this.playerAction(1);
    }

    setEnableHorse(isEnable:boolean) {
        if(isEnable){
            for (let i = 0; i < this.horses.length; i++) {
                let horse = this.horses[i].getComponent(PlayerAnim);
                if (horse.currentCell === this.path.length - 1) {
                    horse.setFocus(false);
                } else {
                    if(this.diceRes==1 || this.diceRes == 6){
                        horse.setFocus(true);
                    }
                    else {
                        if(horse.currentCell<4){
                            horse.setFocus(false);
                        } else {
                            horse.setFocus(true);
                        }
                    }
                }
            }
        } else {
            for (let i = 0; i < this.horses.length; i++) {
                let horse = this.horses[i].getComponent(PlayerAnim);
                horse.setFocus(false);
            }
        }
    }
    countEnableHorse(){
        let count = 0;
        for (let i = 0; i < this.horses.length; i++) {
            let horse = this.horses[i].getComponent(PlayerAnim);
            if(horse.isEnable){
                count++;
            }
        }
        return count;
    }
    checkEndGame() {
        let res = -1;
        let iDone = 0;
        for (let i = 0; i < this.horses.length; i++) {
            let horse = this.horses[i];
            if (horse.getComponent(PlayerAnim).currentCell === this.path.length - 1) {
                iDone++;
            }
        }
        if (iDone == 4) {
            res = this.info.color;
        }
        return res;
    }
    start() {

    }

    update(deltaTime: number) {

    }
}


