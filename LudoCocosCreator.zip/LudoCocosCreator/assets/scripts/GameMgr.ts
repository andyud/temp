import { _decorator, Button, Component, Node,sys } from 'cc';
const { ccclass, property } = _decorator;


@ccclass('GameMgr')
export class GameMgr {
    private static _instance: GameMgr;
    
    numOfPlayer = 2;//2 or 4
    playerColor = 0;
    PLAYER_COLOR = {
        RED:0,
        GREEN:1,
        BLUE:2,
        YELLOW:3
    }
    players = [
        {
            name :"BOT",
            color: this.PLAYER_COLOR.RED,
            isMain:false,
            isActive:false
        },
        {
            name :"BOT",
            color: this.PLAYER_COLOR.GREEN,
            isMain:false,
            isActive:false
        },
        {
            name :"BOT",
            color: this.PLAYER_COLOR.BLUE,
            isMain:false,
            isActive:false
        },
        {
            name :"YOU",
            color: this.PLAYER_COLOR.YELLOW,
            isMain:true,
            isActive:false
        }
    ];
    static get instance () {
        if (this._instance) {
            return this._instance;
        }

        this._instance = new GameMgr();
        return this._instance;
    }
    public initGameInfo(){

    }
    public randomInt(min:number, max:number) {
        min = Math.ceil(min);
        max = Math.floor(max);
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }
}

