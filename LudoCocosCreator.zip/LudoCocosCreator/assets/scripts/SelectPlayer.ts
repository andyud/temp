import { _decorator, Button, Component, Game, Node } from 'cc';
import { GameMgr } from './GameMgr';
const { ccclass, property } = _decorator;

@ccclass('SelectPlayer')
export class SelectPlayer extends Component {
    @property({type:Button})
    btn2Players:Button
    @property({type:Button})
    btn4Players:Button
    cb:()=>void;
    init(_cb:()=>void){
        this.cb = _cb;
    }
    start() {
        this.updateUI();
    }
    onPlayer(event: Event, customEventData: string){
        GameMgr.instance.numOfPlayer= parseInt(customEventData);
        this.updateUI();
    }
    onNext(){
        this.node.active = false;
        this.cb();
    }
    updateUI(){
        this.btn2Players.node.children[0].active = true;
        this.btn2Players.node.children[1].active = false;
        this.btn4Players.node.children[0].active = true;
        this.btn4Players.node.children[1].active = false;
        if(GameMgr.instance.numOfPlayer==2){
            this.btn2Players.node.children[0].active = false;
            this.btn2Players.node.children[1].active = true;
        } else {
            this.btn4Players.node.children[0].active = false;
            this.btn4Players.node.children[1].active = true;
        }
    }
    
}


