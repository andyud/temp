import { _decorator, Component, Node,Animation, Button } from 'cc';
import { GameMgr } from './GameMgr';
const { ccclass, property } = _decorator;

@ccclass('PlayerAnim')
export class PlayerAnim extends Component {
    color = 0;//red
    horseId = 0;
    @property([Node])
    arrColor:Node[] = []
    @property({type:Node})
    focusAnim:Node
    currentCell = 0;
    isCanMove = false;
    isEnable = false;
    touchDone:(horseId:number)=>void;
    init(color:number,horseId:number,touchDone:(horseId:number)=>void){
        this.color = color;
        this.horseId = horseId;
        this.touchDone = touchDone;
        for(let i=0;i<this.arrColor.length;i++){
            if(i==this.color){
                this.arrColor[i].active = true;
            } else {
                this.arrColor[i].active = false;
            }
        }
        
    }
    setFocus(isFocus:boolean){
        this.isEnable = isFocus;
        if(isFocus){
            this.focusAnim.getComponent(Animation).play('circle');
            this.getComponent(Button).interactable = true;
        } else {
            this.focusAnim.getComponent(Animation).stop();
            this.getComponent(Button).interactable = false;
        }
    }
    onTouch(event: Event, customEventData: string){
        this.touchDone(this.horseId);
    }
}


