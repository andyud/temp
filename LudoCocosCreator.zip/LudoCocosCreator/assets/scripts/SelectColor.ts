import { _decorator, Button, Component, Node } from 'cc';
import { GameMgr } from './GameMgr';
const { ccclass, property } = _decorator;

@ccclass('SelectColor')
export class SelectColor extends Component {
    @property({ type: Button })
    btnRed: Button
    @property({ type: Button })
    btnGreen: Button
    @property({ type: Button })
    btnBlue: Button
    @property({ type: Button })
    btnYellow: Button
    cb: () => void;
    init(_cb: () => void) {
        this.cb = _cb;
        this.onSelectColor(null,"0");
    }
    start() {
        this.updateUI();
    }

    updateUI() {
        this.btnRed.node.children[0].active = true;
        this.btnRed.node.children[1].active = false;
        this.btnGreen.node.children[0].active = true;
        this.btnGreen.node.children[1].active = false;
        this.btnBlue.node.children[0].active = true;
        this.btnBlue.node.children[1].active = false;
        this.btnYellow.node.children[0].active = true;
        this.btnYellow.node.children[1].active = false;
        switch (GameMgr.instance.playerColor) {
            case GameMgr.instance.PLAYER_COLOR.RED:
                this.btnRed.node.children[0].active = false;
                this.btnRed.node.children[1].active = true;
                break;
            case GameMgr.instance.PLAYER_COLOR.GREEN:
                this.btnGreen.node.children[0].active = false;
                this.btnGreen.node.children[1].active = true;
                break;
            case GameMgr.instance.PLAYER_COLOR.BLUE:
                this.btnBlue.node.children[0].active = false;
                this.btnBlue.node.children[1].active = true;
                break;
            case GameMgr.instance.PLAYER_COLOR.YELLOW:
                this.btnYellow.node.children[0].active = false;
                this.btnYellow.node.children[1].active = true;
                break;
        }
    }

    onSelectColor(event: Event, customEventData: string) {
        let color = parseInt(customEventData);
        GameMgr.instance.playerColor = color;
        for(let i=0;i<GameMgr.instance.players.length;i++){
            if(i==color){
                GameMgr.instance.players[i].isMain = true;
                GameMgr.instance.players[i].name = 'PLAYER';
                GameMgr.instance.players[i].isActive = true;
            } else {
                GameMgr.instance.players[i].isMain = false;
                GameMgr.instance.players[i].name = 'BOT';
                if(GameMgr.instance.numOfPlayer==4){
                    GameMgr.instance.players[i].isActive = true;
                } else {
                    let nextId = color + 2;
                    if(nextId>=GameMgr.instance.players.length){
                        nextId = 0;
                    }
                    if(i==nextId){
                        GameMgr.instance.players[i].isActive = true;
                    } else{
                        GameMgr.instance.players[i].isActive = false;
                    }
                }
            }
        }
        this.updateUI();
    }

    onPlay() {
        this.node.active = false;
        this.cb();
    }
}

